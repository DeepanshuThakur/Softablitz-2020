package sample;

import java.sql.* ;
public class DBConnection {
    public Connection dblink ;

    public Connection getConnection()
    {
        String databaseName = "ShareNow" ;
        String dbuser = "root" ;
        String dbpassword = "Deepanshu@123" ;
        String url = "jdbc:mysql://localhost/" + databaseName ;

        try
        {
            Class.forName( "com.mysql.cj.jdbc.Driver") ;
            dblink = DriverManager.getConnection( url, dbuser , dbpassword ) ;
        }
        catch( Exception e )
        {
            e.printStackTrace();
            e.getCause() ;
        }

        return dblink ;
    }
}
