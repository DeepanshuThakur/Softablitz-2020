package sample;
import javafx.fxml.FXML ;
import javafx.scene.control.Button ;
import javafx.scene.control.Label ;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage ;
import javafx.event.ActionEvent;

public class Controller_UserPage {
    @FXML
    private Button UploadButton ;

    @FXML
    private Label NewRegisterLabel ;
}
