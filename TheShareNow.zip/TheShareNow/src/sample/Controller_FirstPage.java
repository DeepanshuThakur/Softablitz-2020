package sample;

import javafx.fxml.FXML ;
import javafx.scene.control.Button ;
import javafx.scene.control.Hyperlink ;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage ;
import javafx.event.ActionEvent;

import java.io.IOException;

public class Controller_FirstPage {
    @FXML
    private Button UserPageButton ;
    @FXML
    private Button AdminPageButton ;

    @FXML
    private Hyperlink NewRegisterLink ;

    public void UserPageButtonAction( ActionEvent e )
    {
        Stage primaryStage = (Stage) UserPageButton.getScene().getWindow();
        primaryStage.close() ;
        Parent root = null ;

        try
        {
            root = FXMLLoader.load( getClass().getResource( "UserLogin.fxml")) ;
        }
        catch( IOException ex )
        {
            ex.printStackTrace( ) ;
        }
        primaryStage.setScene( new Scene( root , 1303 , 961 ) ) ;
        primaryStage.show() ;
    }

    public void AdminPageButtonAction( ActionEvent event )
    {
        Stage primaryStage = (Stage) AdminPageButton.getScene().getWindow();
        Parent root = null ;

        try
        {
            root = FXMLLoader.load( getClass().getResource( "AdminLoginPage.fxml")) ;
        }
        catch( IOException ex )
        {
            ex.printStackTrace( ) ;
        }
        primaryStage.setScene( new Scene( root , 1303 , 961 ) ) ;
        primaryStage.show() ;
    }

    public void NewRegisterLinkAction( ActionEvent event )
    {
        Stage primaryStage = (Stage) AdminPageButton.getScene().getWindow();
        Parent root = null ;

        try
        {
            root = FXMLLoader.load( getClass().getResource( "NewRegister.fxml")) ;
        }
        catch( IOException ex )
        {
            ex.printStackTrace( ) ;
        }
        primaryStage.setScene( new Scene( root , 1303 , 961 ) ) ;
        primaryStage.show() ;
    }
}
