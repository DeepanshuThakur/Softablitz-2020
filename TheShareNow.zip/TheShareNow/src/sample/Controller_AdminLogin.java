package sample;

import javafx.fxml.FXML ;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button ;
import javafx.scene.control.TextField ;
import javafx.scene.control.PasswordField ;
import javafx.scene.control.Label ;
import javafx.stage.Stage ;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.sql.Connection ;
import java.sql.Statement ;
import java.sql.ResultSet ;

public class Controller_AdminLogin {

    @FXML
    private Button AdminButton ;
    @FXML
    private Button AdminBackButton ;
    @FXML
    private TextField AdminUField ;
    @FXML
    private PasswordField AdminPField ;
    @FXML
    private Label AdminLoginLabel ;

    public void AdminBackButtonAction( ActionEvent event ) {
        Stage stage = (Stage) AdminBackButton.getScene().getWindow();
        stage.close();
        Parent root = null ;
        try {
            root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));

        }
        catch( IOException ex )
        {
            ex.printStackTrace() ;
        }

        stage.setScene(new Scene(root, 300, 275));
        stage.show();
    }
    public void AdminButtonOnActionEvent( ActionEvent event )
    {
        if( AdminUField.getText().isBlank() == false && AdminPField.getText().isBlank() == false )
        {
            boolean status = validateLogin() ;
            if( status )
            {
                AdminLoginLabel.setText( "Welcome") ;
                try {
                    Thread.sleep(1000);
                }
                catch( Exception e )
                {
                    e.printStackTrace() ;
                }
                Stage stage = (Stage) AdminButton.getScene().getWindow();
                stage.close();
                Parent root = null ;
                try {
                    root = FXMLLoader.load(getClass().getResource("AdminPage.fxml"));

                }
                catch( IOException ex )
                {
                    ex.printStackTrace() ;
                }

                stage.setScene(new Scene(root, 300, 275));
                stage.show();
            }
            else
            {
                AdminLoginLabel.setText( "Invalid Login Credentials. Try again") ;
            }
        }
        else
        {
            AdminLoginLabel.setText( "Error : 1 more or fields are empty") ;
        }
    }

    public boolean validateLogin()
    {
        DBConnection connectNow = new DBConnection() ;
        Connection connectDB = connectNow.getConnection() ;

        String verifyLogin = "select count(1) from adminlogin where username = '" + AdminUField.getText() + "' and password ='" + AdminPField.getText()  + "'" ;
        try
        {
            Statement st = connectDB.createStatement() ;
            ResultSet result = st.executeQuery( verifyLogin ) ;


            while( result.next() )
            {
                if( result.getInt( 1 ) == 1)
                {
                    return true;
                }

            }
        } catch( Exception e )
        {
            e.printStackTrace() ;
        }

        return false ;

    }
}

