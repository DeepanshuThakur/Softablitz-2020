package sample;

public class Controller_NewRegister {
}
