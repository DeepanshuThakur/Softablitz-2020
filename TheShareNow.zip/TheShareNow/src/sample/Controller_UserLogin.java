package sample;

import javafx.fxml.FXML ;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button ;
import javafx.scene.control.TextField ;
import javafx.scene.control.PasswordField ;
import javafx.scene.control.Label ;
import javafx.stage.Stage ;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.sql.Connection ;
import java.sql.Statement ;
import java.sql.ResultSet ;

public class Controller_UserLogin {

    @FXML
    private Button UserButton ;
    @FXML
    private Button BackButton ;
    @FXML
    private TextField UField ;
    @FXML
    private PasswordField PField ;
    @FXML
    private Label LoginLabel ;

    public void BackButtonAction( ActionEvent event ) {
        Stage stage = (Stage) BackButton.getScene().getWindow();
        stage.close();
        Parent root = null ;
        try {
            root = FXMLLoader.load(getClass().getResource("FirstPage.fxml"));

            }
        catch( IOException ex )
        {
            ex.printStackTrace() ;
        }

        stage.setScene(new Scene(root, 300, 275));
        stage.show();
    }
    public void UserButtonOnActionEvent( ActionEvent event )
    {
        if( UField.getText().isBlank() == false && PField.getText().isBlank() == false )
        {
           boolean status = validateLogin() ;
            if( status )
            {
                LoginLabel.setText( "Welcome") ;
                try {
                    Thread.sleep(1000);
                }
                catch( Exception e )
                {
                    e.printStackTrace() ;
                }
                Stage stage = (Stage) UserButton.getScene().getWindow();
                stage.close();
                Parent root = null ;
                try {
                    root = FXMLLoader.load(getClass().getResource("UserPage.fxml"));

                }
                catch( IOException ex )
                {
                    ex.printStackTrace() ;
                }

                stage.setScene(new Scene(root, 300, 275));
                stage.show();
            }
            else
            {
                LoginLabel.setText( "Invalid Login Credentials. Try again") ;
            }
        }
        else
        {
            LoginLabel.setText( "Error : 1 more or fields are empty") ;
        }
    }

    public boolean validateLogin()
    {
        DBConnection connectNow = new DBConnection() ;
        Connection connectDB = connectNow.getConnection() ;

        String verifyLogin = "select count(1) from userlogin where username = '" + UField.getText() + "' and password ='" + PField.getText()  + "'" ;
        try
        {
            Statement st = connectDB.createStatement() ;
            ResultSet result = st.executeQuery( verifyLogin ) ;


            while( result.next() )
            {
                if( result.getInt( 1 ) == 1)
                {
                    return true;
                }

            }
        } catch( Exception e )
        {
            e.printStackTrace() ;
        }

        return false ;

    }
}
