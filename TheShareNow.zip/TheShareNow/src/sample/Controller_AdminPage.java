package sample;

public class Controller_AdminPage {

}
